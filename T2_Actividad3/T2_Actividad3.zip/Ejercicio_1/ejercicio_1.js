frasesGraciosasInformatica = [
    "La nube no es más que el ordenador de otra persona con tus problemas.",
    "Mi código no tiene bugs, solo características inesperadas",
    "He hecho un curso de Python, y ahora entiendo por qué las serpientes son tan traicioneras.",
    "Dicen que el WiFi es como el amor: cuando más lo necesitas, menos señal tienes."
]


